using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class OyuncuCan : MonoBehaviour
{
    public static OyuncuCan instance;
    public int can;
    public int maxcan;
    public float g�r�nmezliks�re = 1f;
    private float g�r�nmezlikcounter;
    public GameObject �lmeEfekti;

    
    private void Awake()
    {
        
        
        if(instance == null)
        {
            instance = this;
        }
        
    }
    
    
    // Start is called before the first frame update
    void Start()
    {
        maxcan = SaveManager.instance.activeSave.maxHealth;
        can = maxcan;
        UIManager.instance.UpdateCan();

    }

    // Update is called once per frame
    void Update()
    {
        if(g�r�nmezlikcounter > 0)
        {
            g�r�nmezlikcounter -= Time.deltaTime;
        }
    }
    public void OyuncuHasar(int hasaroran�)
    {
        if (�lmeEfekti != null)
        {
            Instantiate(�lmeEfekti, transform.position, transform.rotation);
        }



        if (g�r�nmezlikcounter <= 0)
        {


            can -= hasaroran�;

            g�r�nmezlikcounter = g�r�nmezliks�re;

            if(can <= 0)
            {
                can = 0;

                gameObject.SetActive(false);

                Instantiate(�lmeEfekti, transform.position, transform.rotation);

                AudioManager.instance.PlaySFX(4);

                GameManager.instance.Respawn();
            }

            UIManager.instance.UpdateCan();

            AudioManager.instance.PlaySFX(7);

            
        }
    }
    public void RestoreHealth(int healthToRestore)
    {
        can += healthToRestore;

        if(can > maxcan)
        {
            can = maxcan;
        }
        UIManager.instance.UpdateCan();
    }
}
